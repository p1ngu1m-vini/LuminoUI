-- VERSÃO [0.0.1]

local screenWidth, screenHeight = guiGetScreenSize()

---- dxDrawInput ----
local inputText = ""
local isInputFocused = false
local cursorBlinkTime = 500
local lastCursorBlink = 0
local cursorVisible = true
local cursorPosition = 0
---- dxDrawPercentageText ----
local duration = 10000
local percentInicial = 0
local percentFinal = 100
---------------------------------------------------------------------------
function dxDrawButton(x, y, width, height, radius, color, colorHover, text, fontSize, fontFamily, onClick)
    local mouseX, mouseY = getCursorPosition()
    mouseX, mouseY = mouseX * screenWidth, mouseY * screenHeight
    local isHovering = (mouseX >= x and mouseX <= x + width and mouseY >= y and mouseY <= y + height)

    local bgColor = color
    if isHovering then
        bgColor = colorHover
    end

    dxDrawRoundedRectangle(x, y, width, height, radius, tocolor(bgColor[1], bgColor[2], bgColor[3], bgColor[4]), false, true)

    local textX = x + width / 2
    local textY = y + height / 2
    dxDrawText(text, textX, textY, textX, textY, tocolor(255, 255, 255, 255), fontSize or 1, fontFamily or "default-bold", "center", "center", false, false, true)

    if isHovering and getKeyState("mouse1") then
        if not isButtonClicked then
            isButtonClicked = true
            onClick()
        end
    else
        isButtonClicked = false
    end
end
---------------------------------------------------------------------------
function dxDrawRoundedRectangle(x, y, width, height, radius, color, postGUI, subPixelPositioning)
    dxDrawRectangle(x+radius, y+radius, width-(radius*2), height-(radius*2), color, postGUI, subPixelPositioning)
    dxDrawCircle(x+radius, y+radius, radius, 180, 270, color, color, 16, 1, postGUI)
    dxDrawCircle(x+radius, (y+height)-radius, radius, 90, 180, color, color, 16, 1, postGUI)
    dxDrawCircle((x+width)-radius, (y+height)-radius, radius, 0, 90, color, color, 16, 1, postGUI)
    dxDrawCircle((x+width)-radius, y+radius, radius, 270, 360, color, color, 16, 1, postGUI)
    dxDrawRectangle(x, y+radius, radius, height-(radius*2), color, postGUI, subPixelPositioning)
    dxDrawRectangle(x+radius, y+height-radius, width-(radius*2), radius, color, postGUI, subPixelPositioning)
    dxDrawRectangle(x+width-radius, y+radius, radius, height-(radius*2), color, postGUI, subPixelPositioning)
    dxDrawRectangle(x+radius, y, width-(radius*2), radius, color, postGUI, subPixelPositioning)
end
---------------------------------------------------------------------------
function dxDrawTextWithBorder(text, x, y, width, height, color, scale, font, alignX, alignY, clip, wordBreak, postGUI, borderColor)
    dxDrawText(text, x + 1, y, x + 1, y, borderColor, scale, font, alignX, alignY, clip, wordBreak, postGUI)
    dxDrawText(text, x - 1, y, x - 1, y, borderColor, scale, font, alignX, alignY, clip, wordBreak, postGUI)
    dxDrawText(text, x, y + 1, x, y + 1, borderColor, scale, font, alignX, alignY, clip, wordBreak, postGUI)
    dxDrawText(text, x, y - 1, x, y - 1, borderColor, scale, font, alignX, alignY, clip, wordBreak, postGUI)
    dxDrawText(text, x, y, x, y, color, scale, font, alignX, alignY, clip, wordBreak, postGUI)
end
---------------------------------------------------------------------------
function dxDrawInput(inputText, x, y, width, height, radius, colorText, colorBackground, postGUI)
    dxDrawRoundedRectangle(x, y, width, height, radius, colorBackground, postGUI, true)

    local mouseX, mouseY = getCursorPosition()
    mouseX, mouseY = mouseX * screenWidth, mouseY * screenHeight
    local isHovering = (mouseX >= x and mouseX <= x + width and mouseY >= y and mouseY <= y + height)

    if isHovering and getKeyState("mouse1") then
        isInputFocused = true
        local clickX = mouseX - x
        local textWidth = dxGetTextWidth(inputText, 1, "default-bold")
        cursorPosition = math.floor((clickX - 10) / (textWidth + 10) * #inputText)
    elseif getKeyState("mouse1") then
        isInputFocused = false
    end

    dxDrawText(inputText, x + 10, y + (height / 2), x + 10, y + (height / 2), colorText, 1, "default-bold", "left", "center", false, false, postGUI)

    local currentTime = getTickCount()
    if isInputFocused then
        if currentTime - lastCursorBlink >= cursorBlinkTime then
            cursorVisible = not cursorVisible
            lastCursorBlink = currentTime
        end
        if cursorVisible then
            local textWidth = dxGetTextWidth(inputText:sub(1, cursorPosition), 1, "default-bold")
            dxDrawLine(x + 10 + textWidth, y + 5, x + 10 + textWidth, y + height - 5, tocolor(0, 0, 0, 255), 1, postGUI)
        end

        local char = getChatboxInput("default", 0)
        if char then
            inputText = inputText:sub(1, cursorPosition) .. char .. inputText:sub(cursorPosition + 1)
            cursorPosition = cursorPosition + 1
        end

        if getKeyState("arrow_l") then
            cursorPosition = math.max(0, cursorPosition - 1)
        elseif getKeyState("arrow_r") then
            cursorPosition = math.min(#inputText, cursorPosition + 1)
        end
    end
end
---------------------------------------------------------------------------
function dxDrawScrollableList(x, y, width, height, items, selectedIndex, bgColor, textColor, selectedColor, fontSize, fontFamily, onClick)
    dxDrawRoundedRectangle(x, y, width, height, 5, bgColor, false, true)

    local itemHeight = height / #items
    local mouseX, mouseY = getCursorPosition()
    mouseX, mouseY = mouseX * screenWidth, mouseY * screenHeight

    local isMouseClicked = getKeyState("mouse1")
    local itemClicked = nil

    local startY = y
    for i, item in ipairs(items) do
        local itemY = startY + (i - 1) * itemHeight
        local itemWidth = width

        local isHovering = (mouseX >= x and mouseX <= x + itemWidth and mouseY >= itemY and mouseY <= itemY + itemHeight)

        if isHovering and isMouseClicked and not itemClicked then
            itemClicked = i
        end

        if i == selectedIndex then
            dxDrawRectangle(x, itemY, itemWidth, itemHeight, selectedColor, false, true)
        end

        dxDrawText(item, x + itemWidth / 2, itemY + itemHeight / 2, x + itemWidth / 2, itemY + itemHeight / 2, textColor, fontSize or 1, fontFamily or "default-bold", "center", "center", false, false, true)
    end

    if itemClicked then
        onClick(itemClicked, items[itemClicked])
    end
end
---------------------------------------------------------------------------
function dxDrawPercentageText(x, y, width, height, percentInicial, percentFinal, duration, color, font, alignX, alignY, functionPorcentagemEnd, postGUI)
    local startTime = getTickCount()
    local percent = percentInicial
    local hasEnded = false

    local thisHandler

    thisHandler = addEventHandler("onClientRender", root, function()
        local elapsedTime = getTickCount() - startTime
        local progress = elapsedTime / duration

        percent = percentInicial + progress * (percentFinal - percentInicial)
        percent = math.min(percent, percentFinal)

        dxDrawText(tostring(math.floor(percent)) .. "%", x, y, x + width, y + height, color, 1, font, alignX, alignY, false, false, postGUI)

        if percent >= percentFinal and not hasEnded then
            if type(functionPorcentagemEnd) == "function" then
                functionPorcentagemEnd()
                hasEnded = true
                removeEventHandler("onClientRender", root, thisHandler)
            end
        end
    end)
end
---------------------------------------------------------------------------
function dxDrawNotification(x, y, width, height, text, bgColor, textColor, duration)
    dxDrawRoundedRectangle(x, y, width, height, 5, bgColor, false, true)

    dxDrawText(text, x, y, x + width, y + height, textColor, 1, "default-bold", "center", "center", false, false, true)

    setTimer(function()
    end, duration, 1)
end
---------------------------------------------------------------------------
function dxDrawToggleButton(x, y, width, height, isActive, activeColor, inactiveColor, text, fontSize, fontFamily, onClick)
    local mouseX, mouseY = getCursorPosition()
    mouseX, mouseY = mouseX * screenWidth, mouseY * screenHeight

    local isHovering = (mouseX >= x and mouseX <= x + width and mouseY >= y and mouseY <= y + height)
    local bgColor = isActive and activeColor or inactiveColor

    dxDrawRoundedRectangle(x, y, width, height, 5, tocolor(bgColor[1], bgColor[2], bgColor[3], bgColor[4]), false, true)

    local textX = x + width / 2
    local textY = y + height / 2
    dxDrawText(text, textX, textY, textX, textY, tocolor(255, 255, 255, 255), fontSize or 1, fontFamily or "default-bold", "center", "center", false, false, true)

    if isHovering and getKeyState("mouse1") and not wasClicking then
        wasClicking = true
        onClick(not isActive)
    elseif not getKeyState("mouse1") then
        wasClicking = false
    end
end
---------------------------------------------------------------------------
function dxDrawCheckBox(x, y, size, isChecked, borderColor, checkColor, bgColor, text, fontSize, fontFamily, onClick)
    local checkMarker = false
    local boxWidth = size
    local boxHeight = size
    local boxX = x
    local boxY = y

    local mouseX, mouseY = getCursorPosition()
    mouseX, mouseY = mouseX * screenWidth, mouseY * screenHeight

    local isHovering = (mouseX >= boxX and mouseX <= boxX + boxWidth and mouseY >= boxY and mouseY <= boxY + boxHeight)

    dxDrawRectangle(boxX, boxY, boxWidth, boxHeight, bgColor, false, true)
    dxDrawRectangle(boxX, boxY, boxWidth, boxHeight, borderColor, false, true)

    if isChecked then
        dxDrawLine(boxX, boxY, boxX + boxWidth, boxY + boxHeight, checkColor, 2, false)
        dxDrawLine(boxX + boxWidth, boxY, boxX, boxY + boxHeight, checkColor, 2, false)
    end

    local textX = boxX + boxWidth + 10
    local textY = y
    dxDrawText(text, textX, textY, textX, textY, tocolor(255, 255, 255, 255), fontSize or 1, fontFamily or "default-bold", "left", "top", false, false, true)

    if isHovering and getKeyState("mouse1") then
        onClick(not isChecked)
    end 
end
function isCheckBoxChecked()
    return checkMarker
end   
---------------------------------------------------------------------------
function isCursos(x, y, width, height)
    local mouseX, mouseY = getCursorPosition()
    local screenX, screenY = guiGetScreenSize()
    mouseX, mouseY = mouseX * screenX, mouseY * screenY
    return (mouseX >= x and mouseX <= x + width and mouseY >= y and mouseY <= y + height)
end